package com.zycus.model.monster.pawn;

import com.zycus.model.monster.Pawn;

public class Brawler extends Pawn {
	private String gene = "brawler";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Brawler() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Brawler(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Brawler(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Brawler [gene=" + gene + "]";
	}

}
