package com.zycus.model.human.gatherer.collector;

import com.zycus.model.human.gatherer.Collector;

public class Hoarder extends Collector {
	private String gene = "hoarder";

	public Hoarder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	@Override
	public String toString() {
		return "Hoarder [gene=" + gene + "]";
	}

}
