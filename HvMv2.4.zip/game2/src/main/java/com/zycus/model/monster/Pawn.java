package com.zycus.model.monster;

import com.zycus.model.creature.Monster;

public class Pawn extends Monster {
	private String gene = "pawn";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Pawn() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pawn(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Pawn(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Pawn [gene=" + gene + "]";
	}

}
