package com.zycus.model.monster.goblin;

import com.zycus.model.monster.Goblin;

public class Hoarder extends Goblin {
	private int level = 3;
	private String gene = "hoarder";

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Hoarder() {
		super();
		super.setUpgradeCost(20);
		// super.setGene("hoarder");
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Hoarder [level=" + level + ", gene=" + gene + "]";
	}

}
