package com.zycus.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.Block;
import com.zycus.model.Board;
import com.zycus.model.Creature;
import com.zycus.model.human.Human;
import com.zycus.model.monster.Monster;

@Controller
public class GameController {

	@Autowired
	Board gameMat;
	
	int flag = 1;
	
	String chance()
	{
		flag*=-1;
		if(flag < 0)
			return "monster";
		return "human";
	}

	@RequestMapping(value = "index", method = RequestMethod.GET)
	public String getIndex() {
		return "/index";
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getIndex1() {
		return "/index";
	}

	// GAME START HERE
	@RequestMapping(value = "startGame", method = RequestMethod.GET)
	public String startGame(HttpSession session) {
		
		ArrayList<ArrayList<Block>> gameMat = new ArrayList<ArrayList<Block>>();

		ArrayList<Block> listOfBlocks;

		Block block;

		for (int i = 0; i < 10; i++) {

			listOfBlocks = new ArrayList<Block>();

			for (int j = 0; j < 10; j++) {
				if (i == 0)
					block = new Block(new Human(), i, j);
				else if (i == 9)
					block = new Block(new Monster(), i, j);
				else
					block = new Block(null, i, j);

				listOfBlocks.add(block);
			}
			gameMat.add(listOfBlocks);
		}

		session.setAttribute("mode", "move");
		
		session.setAttribute("row", 0);
		session.setAttribute("col", 0);
		
		session.setAttribute("plays", chance());
		
		session.setAttribute("pastCreature", null);
		
		session.setAttribute("board", gameMat);

		return "/startGame";
	}

	@RequestMapping(value = "setModeMove", method = RequestMethod.GET)
	public String setModeMove(HttpSession session) {
		session.setAttribute("mode", "move");
		return "/startGame";
	}

	@RequestMapping(value = "setModeAttack", method = RequestMethod.GET)
	public String setModeAttack(HttpSession session) {
		session.setAttribute("mode", "attack");
		return "/startGame";
	}

	@RequestMapping(value = "/ingame/{mode}/{row}/{col}", method = RequestMethod.GET)
	public String makeMove(@PathVariable("mode") String mode, @PathVariable("row") int row,
			@PathVariable("col") int col, HttpSession session) {

		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		ArrayList<Block> listOfBlocks;

		if (mode.equals("attack")) {
			session.setAttribute("mode", "attacking");
		} else {
			if (mode.equals("move")) {
				session.setAttribute("mode", "moving");
				session.setAttribute("pastCreature", gameMat.get(row).get(col).getCreature().getMovementRange());
				session.setAttribute("row", row);
				session.setAttribute("col", col);
			} else {
				if (mode.equals("moving")) {

					ArrayList<Block> listOfBlocks1;
					ArrayList<Block> listOfBlocks2;

					Block oldBlock;
					Block newBlock;

					int prevRow = (Integer) session.getAttribute("row");
					int prevCol = (Integer) session.getAttribute("col");
 
					listOfBlocks1 = gameMat.get(prevRow);
					oldBlock = listOfBlocks1.get(prevCol);

					newBlock = new Block(oldBlock.getCreature(), row, col);

					listOfBlocks2 = gameMat.get(row);
					listOfBlocks2.set(col, newBlock);

					oldBlock.setCreature(null);

					listOfBlocks1.set(prevCol, oldBlock);

					gameMat.set(prevRow, listOfBlocks1);
					gameMat.set(row, listOfBlocks2);

					session.setAttribute("board", gameMat);
					session.setAttribute("plays", chance());
					session.setAttribute("mode", "move");

				}
			}
		}

		return "/startGame";
	}
}
