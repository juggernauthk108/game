package com.zycus.support;


public class ChanceMechanism {
	
	private static int flag = (DieRoll.dieRoll() % 2 > 0) ? 1 : -1;
	
	public static int getFlag() {
		return flag;
	}

	public static void setFlag(int flag) {
		ChanceMechanism.flag = flag;
	}

	public static String chance() {
		flag *= -1;
		if (flag < 0)
			return "monster";
		return "human";
	}
	
	public static String getOpp(String gene)
	{
		if(gene.equalsIgnoreCase("human"))
			return "monster";
		return "human";
	}
}
