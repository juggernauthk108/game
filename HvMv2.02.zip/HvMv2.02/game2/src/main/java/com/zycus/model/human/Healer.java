package com.zycus.model.human;

import com.zycus.model.creature.Human;

public class Healer extends Human {

	private int level = 2;
	private String gene = "healer";

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Healer() {
		super();
		super.setUpgradeCost(10);
		//super.setGene("healer");
		// TODO Auto-generated constructor stub
	}

	public Healer(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Healer(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Healer [level=" + level + ", gene=" + gene + "]";
	}

}
