package com.zycus.passwordmanager.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.passwordmanager.dao.UserDao;
import com.zycus.passwordmanager.model.User;

@Repository
public class UserDaoImpl implements UserDao{
	
	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	public boolean register(User user)
	{
		String checkIfExists = "from User where userEmail = ?";
		List<User> list = (List<User>) hibernateTemplate.find(checkIfExists, user.getUserEmail());
		if(list.size()==0)
		{
		Integer entry = (Integer) hibernateTemplate.save(user);
			if(entry!=null)
			{
				System.out.println("Entered account creation.");
				return true;
			}
		}
		System.out.println("Account creation failed. User already exists.");
		return false;
	}
	
	public User authenticate(User user)
	{
		String query = "from User where userEmail=? and userPassword=?";
		List<User> userList = (List<User>) hibernateTemplate.find(query, new Object[] { user.getUserEmail(), user.getUserPassword() });
		if (userList.size()==1)
			return userList.get(0);
		return null;
	}
}