package com.zycus.model.human;

import com.zycus.model.creature.Human;

public class Slinger extends Human {
	private String gene = "slinger";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Slinger() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Slinger(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Slinger(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Slinger [gene=" + gene + "]";
	}

}
