package com.zycus.support;

import javax.servlet.http.HttpSession;

public class EndTurnMechanism {
	
	public static void endTurnMechanism(HttpSession session) {
		int initFlagState = (Integer) session.getAttribute("initFlagState");

		if (ChanceMechanism.getFlag() == initFlagState) {
			session.setAttribute("noOfTurns",
					(Integer) session.getAttribute("noOfTurns") + 1);
			grantPassiveMoney(session);
		}
		
		int rosRow = (Integer) session.getAttribute("rosRow");
		int rosCol = (Integer) session.getAttribute("rosRow");
		
		/*
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		Roshan roshan = (Roshan) gameMat.get(rosRow).get(rosCol).getCreature();
		
		if(roshan.getState().equals("angry"))
		{
			if(roshan.getAngryFor() - 1 == 0)
			{
				roshan.setState("calm");
			}
			else{
				roshan.setAngryFor(roshan.getAngryFor() - 1);
			}
			
		}
		
*/		/*
		if(Roshan.getState() == "angry")
		{
			if(Roshan.getAngryFor() - 1 == 0)
				Roshan.setState("calm");
			Roshan.setAngryFor(Roshan.getAngryFor() - 1);
		}
		*/
		
	}

	public static void grantPassiveMoney(HttpSession session) {

		session.setAttribute("monsterMoney",
				(Integer) session.getAttribute("monsterMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

		session.setAttribute("humanMoney",
				(Integer) session.getAttribute("humanMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

	}
}
