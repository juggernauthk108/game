package com.zycus.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.action.Action;
import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.support.ChanceMechanism;
import com.zycus.support.Console;
import com.zycus.support.CreatureSet;
import com.zycus.support.DieRoll;
import com.zycus.support.EndTurnMechanism;
import com.zycus.support.PossibleUpgrades;

@Controller
public class IngameController {

	@RequestMapping(value = "/ingame/{mode}/{row}/{col}", method = RequestMethod.GET)
	public String makeMove(@PathVariable("mode") String mode,
			@PathVariable("row") int row, @PathVariable("col") int col,
			HttpSession session) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {

		int prevRow = (Integer) session.getAttribute("row");
		int prevCol = (Integer) session.getAttribute("col");
		
		CreatureSet creatureSet = new CreatureSet();

		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		
		ArrayList<Block> listOfBlocks;

		if (mode.equals("attack")) {
			session.setAttribute("attackRange", gameMat.get(row).get(col).getCreature().getAttackRange());
			session.setAttribute("mode", "attacking");
			session.setAttribute("row", row);
			session.setAttribute("col", col);

		} else {
			if (mode.equals("move")) {
				session.setAttribute("mode", "moving");
				session.setAttribute("pastCreature", gameMat.get(row).get(col).getCreature().getMovementRange());
				session.setAttribute("row", row);
				session.setAttribute("col", col);
			} else {
				if (mode.equals("moving")) {

					
				
					Action action = new Action();
					
					gameMat = action.moveCreature(gameMat, prevRow, prevCol, row, col);
					
					String plays = (String) session.getAttribute("plays");
					
					boolean isHumanOrNo = creatureSet.isHuman(plays);

					//updating the CreatureSet
					creatureSet.updateSet(plays, gameMat.get(prevRow).get(prevCol), gameMat.get(row).get(col));
					
					Console.moved(plays, prevRow, prevCol, row, col, session);
					session.setAttribute("console", Console.getConsole());

					session.setAttribute("board", gameMat);
					session.setAttribute("opp", plays);
					session.setAttribute("plays", ChanceMechanism.chance());
					session.setAttribute("mode", "move");
					
					EndTurnMechanism.endTurnMechanism(session);
					

				} else {
					if (mode.equals("attacking")) {
						

						Creature sourceCreature = gameMat
								.get(prevRow)
								.get(prevCol)
								.getCreature();
						
						int attackpoints = sourceCreature.getAttackPoints();
						int accuracy = sourceCreature.getAccuracy();

						Creature opponent = gameMat.get(row).get(col).getCreature();
						
						int oppLife = opponent.getLife();
						int oppArmor = opponent.getArmor();

						if (DieRoll.dieRoll() < accuracy) {
							attackpoints -= (oppArmor * attackpoints) / 100;

							// minimum attack points
							if (attackpoints <= 0)
								attackpoints = 80;
							else {
								int delta = (new Random()
										.nextInt(attackpoints / 4)) + 1;

								if (DieRoll.dieRoll() % 2 == 0)
									attackpoints += delta;
								else
									attackpoints -= delta;

								if (delta > attackpoints / 5) {
									System.out.println("CRITICAL HIT");
								}
							}

							// attack : reduce the life
							oppLife -= attackpoints;

							if (oppLife > 0) {
								gameMat.get(row).get(col).getCreature()
										.setLife(oppLife);

								// reduce the armor
								gameMat.get(row).get(col).getCreature()
										.setArmor(oppArmor - 1);
							}

							else {
								gameMat.get(row).get(col).setCreature(null);
								creatureSet.remove((String)session.getAttribute("plays"), gameMat.get(row).get(col));

							}

						}

						else {
							System.out.println(sourceCreature.getGene()
									+ " missed");
						}

						String plays = (String)session.getAttribute("plays");
						
						Console.attacked(plays, prevRow, prevCol, row, col, session);
						session.setAttribute("console", Console.getConsole());

						session.setAttribute("board", gameMat);
						session.setAttribute("opp", session.getAttribute("plays"));
						session.setAttribute("plays", ChanceMechanism.chance());
						// session.setAttribute("noOfTurns", (Integer)
						// session.getAttribute("noOfTurns") + 1);
						EndTurnMechanism.endTurnMechanism(session);
						session.setAttribute("mode", "move");

					}

					else {
						if (mode.equals("collect")) {
							// session.setAttribute("mode", "collecting");

							if (gameMat.get(row).get(col).getMoney() != null) {

								int gotMoneyFromBlock = gameMat.get(row)
										.get(col).getAmountMoney();

								if (session.getAttribute("plays").equals(
										"monster"))
									session.setAttribute(
											"monsterMoney",
											(Integer) session
													.getAttribute("monsterMoney")
													+ gotMoneyFromBlock);
								else
									session.setAttribute(
											"humanMoney",
											(Integer) session
													.getAttribute("humanMoney")
													+ gotMoneyFromBlock);

								Console.collected((String)session.getAttribute("plays"), prevRow, prevCol, session);
								session.setAttribute("console", Console.getConsole());

								gameMat.get(row).get(col).setMoney(null);

								session.setAttribute("opp",
										session.getAttribute("plays"));
								session.setAttribute("plays", ChanceMechanism.chance());

								// session.setAttribute("noOfTurns", (Integer)
								// session.getAttribute("noOfTurns") + 1);
								EndTurnMechanism.endTurnMechanism(session);
								session.setAttribute("board", gameMat);
							} else {
								System.out.println("no resources to collect");
							}

							session.setAttribute("mode", "move");

						}
						else
						{
							if(mode.equals("upgrade"))
							{
								System.out.println("upgrading "+row+", "+col);
								
								ArrayList<Creature> creatureList = new ArrayList<Creature>();
								ArrayList<Creature> availableUpgradeList = new ArrayList<Creature>();

								System.out.println("getting creature from "+prevRow+", "+prevCol);
								
								Creature currCreature = gameMat.get(row).get(col).getCreature();
								
								System.out.println("this is the creature picked up: "+currCreature);
								
								String plays = (String)session.getAttribute("plays");
								
								boolean isPossible = false;
								
								int balance = 0;
								
								if(creatureSet.isHuman(plays))
								{
									 creatureList = PossibleUpgrades.getPossibleHumanUpgradeList();
									 balance = (Integer) session.getAttribute("monsterMoney");
								}
								else
								{
									creatureList = PossibleUpgrades.getPossibleMonsterUpgradeList();
									balance = (Integer) session.getAttribute("humanMoney");
								}
							
								//remove this after testing is done
								balance = 1000;
								
								System.out.print("Available Creature upgrades: ");
								for(Creature creature : creatureList)
								{
									if(creature.getLevel() - currCreature.getLevel() == 1)
									{
										System.out.print(creature.getGene()+", ");
										
										if(balance >= creature.getUpgradeCost())
										{
											availableUpgradeList.add(creature);
											balance -= creature.getUpgradeCost();
											isPossible = true;
										}
										else
											System.out.println("you had insufficient balance for "+creature.getGene());
									}
										
									/*
									 * About breaking condition
									 * 
									 * This is to optimize this section
									 * 
									 * WARNING: for this to work, the creatures should be inserted in proper order in PossibleUpgrade methods
									 * 			if this is unclear: don't play around and call the developers, Peace.
									 *
									 * */
									
									/*
									if(creature.getLevel() - currCreature.getLevel() > 1)
										break;
										*/
								}
								
								session.setAttribute("row", row);
								session.setAttribute("col", col);
								
								if(isPossible)
								{
									session.setAttribute("mode", "upgrading");
									session.setAttribute("availableUpgradeList", availableUpgradeList);
								}
								else
								{
									session.setAttribute("mode", "move");
								}
								
								session.setAttribute("board", gameMat);
							}
							
							else
							{
								if(mode.equals("upgrading"))
								{
									//upgrading happens here
									System.out.println("this will upgrade and endturn");
									
									session.setAttribute("row", row);
									session.setAttribute("col", col);
									
									session.setAttribute("opp", session.getAttribute("plays"));
									session.setAttribute("plays", ChanceMechanism.chance());
									
									EndTurnMechanism.endTurnMechanism(session);
								}
							}
						}

					}

				}
			}
		}
		return "/startGame";
	}
}
