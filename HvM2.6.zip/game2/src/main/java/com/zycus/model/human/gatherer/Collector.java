package com.zycus.model.human.gatherer;

import com.zycus.model.human.Gatherer;

public class Collector extends Gatherer {
	private String gene = "collector";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Collector() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Collector(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Collector(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Collector [gene=" + gene + "]";
	}

}
