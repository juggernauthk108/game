package com.zycus.model.monster.pawn.brawler;

import com.zycus.model.monster.pawn.Brawler;

public class Chief extends Brawler {
	private String gene = "chief";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Chief() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Chief(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Chief(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Chief [gene=" + gene + "]";
	}

}
