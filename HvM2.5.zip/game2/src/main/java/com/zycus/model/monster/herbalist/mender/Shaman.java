package com.zycus.model.monster.herbalist.mender;

import com.zycus.model.monster.herbalist.Mender;

public class Shaman extends Mender {
	private String gene = "shaman";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Shaman() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Shaman(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Shaman(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Shaman [gene=" + gene + "]";
	}

}
