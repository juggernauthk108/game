package com.zycus.model.monster;

public class Hoarder extends Monster {
	private int level = 3;
	private String gene = "hoarder";

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Hoarder() {
		super();
		super.setUpgradeCost(20);
		super.setGene("hoarder");
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Hoarder(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

}
