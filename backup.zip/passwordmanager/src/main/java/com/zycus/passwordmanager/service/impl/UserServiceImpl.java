package com.zycus.passwordmanager.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.passwordmanager.dao.UserDao;
import com.zycus.passwordmanager.model.User;
import com.zycus.passwordmanager.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public User authenticate(User user) {
		return userDao.authenticate(user);
	}

	@Transactional
	public boolean register(User user) {		
		return userDao.register(user);
	}
	
}
