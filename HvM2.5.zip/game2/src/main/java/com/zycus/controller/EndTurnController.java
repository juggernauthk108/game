package com.zycus.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.support.ChanceMechanism;
import com.zycus.support.Console;
import com.zycus.support.EndTurnMechanism;

@Controller
public class EndTurnController {
	@RequestMapping(value = "/endTurn", method = RequestMethod.GET)
	String endTurn(HttpSession session) {
		
		String plays = (String) session.getAttribute("plays");

		session.setAttribute("opp", plays);

		session.setAttribute("mode", "move");
		
		session.setAttribute("plays", ChanceMechanism.chance());

		Console.endTurn(plays, session);
		
		EndTurnMechanism.endTurnMechanism(session);
		
		return "/startGame";
	}
}
