package com.zycus.passwordmanager.service;

import com.zycus.passwordmanager.model.User;

public interface UserService {
	public User authenticate(User user);
	public boolean register(User user);
}
