package com.zycus.model;

public class Creature {
	private int life;
	private int movementRange = 3;

	public Creature(int life, int movementRange) {
		super();
		this.life = life;
		this.movementRange = movementRange;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public int getMovementRange() {
		return movementRange;
	}

	public void setMovementRange(int movementRange) {
		this.movementRange = movementRange;
	}

	public Creature() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Creature [life=" + life + ", movementRange=" + movementRange + "]";
	}

}
