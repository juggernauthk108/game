package com.zycus.model.monster.claw;

import com.zycus.model.monster.Claw;

/**
 * @author tejas.zarekar
 * 
 */
public class Sorcerer extends Claw {
	private String gene = "sorcerer";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Sorcerer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sorcerer(int life, int movementRange, String gene,
			int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Sorcerer(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Sorcerer [gene=" + gene + "]";
	}

}
