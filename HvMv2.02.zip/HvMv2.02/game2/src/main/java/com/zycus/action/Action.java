package com.zycus.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.model.creature.Reaper;
import com.zycus.support.ChanceMechanism;
import com.zycus.support.Console;
import com.zycus.support.CreatureSet;
import com.zycus.support.DieRoll;
import com.zycus.support.EndTurnMechanism;

public class Action {

	public ArrayList<ArrayList<Block>> moveCreature(ArrayList<ArrayList<Block>> gameMat, int prevRow, int prevCol, int row, int col)
	{
		Block tempBlock = ((List<ArrayList<Block>>) gameMat).get(prevRow).get(prevCol);

		((List<ArrayList<Block>>) gameMat).get(row).get(col).setCreature(tempBlock.getCreature());

		tempBlock.setCreature(null);

		((List<ArrayList<Block>>) gameMat).get(prevRow).set(prevCol, tempBlock);
		
		return gameMat;
	}
	
	public ArrayList<ArrayList<Block>> attackCreature(HttpSession session, ArrayList<ArrayList<Block>> gameMat, int prevRow, int prevCol, int row, int col)
	
	{

		CreatureSet creatureSet = new CreatureSet();
		
		Creature sourceCreature = gameMat
				.get(prevRow)
				.get(prevCol)
				.getCreature();
		
		int attackpoints = sourceCreature.getAttackPoints();
		int accuracy = sourceCreature.getAccuracy();

		Creature opponent = gameMat.get(row).get(col).getCreature();
		
		if(opponent.getGene() == "roshan")
		{
			Reaper roshan = (Reaper) gameMat.get(row).get(col).getCreature();
			roshan.setState("angry");
			roshan.setAngryFor(10);
		}
		
		int oppLife = opponent.getLife();
		int oppArmor = opponent.getArmor();

		if (DieRoll.dieRoll() < accuracy) {
			attackpoints -= (oppArmor * attackpoints) / 100;

			// minimum attack points
			if (attackpoints <= 0)
				attackpoints = 80;
			
			else {
				int delta = (new Random()
						.nextInt(attackpoints / 4)) + 1;

				if (DieRoll.dieRoll() % 2 == 0)
					attackpoints += delta;
				else
					attackpoints -= delta;

				if (delta > attackpoints / 5) {
					System.out.println("CRITICAL HIT");
				}
			}

			// attack : reduce the life
			oppLife -= attackpoints;

			if (oppLife > 0) {
				gameMat.get(row).get(col).getCreature()
						.setLife(oppLife);

				// reduce the armor
				gameMat.get(row).get(col).getCreature()
						.setArmor(oppArmor - 1);
			}

			else {
				gameMat.get(row).get(col).setCreature(null);
				creatureSet.remove((String)session.getAttribute("plays"), gameMat.get(row).get(col));

			}

		}

		else {
			System.out.println(sourceCreature.getGene()
					+ " missed");
		}

		String plays = (String)session.getAttribute("plays");
		
		Console.attacked(plays, prevRow, prevCol, row, col, session);
		session.setAttribute("console", Console.getConsole());

		session.setAttribute("board", gameMat);
		session.setAttribute("opp", session.getAttribute("plays"));
		session.setAttribute("plays", ChanceMechanism.chance());
		// session.setAttribute("noOfTurns", (Integer)
		// session.getAttribute("noOfTurns") + 1);
		EndTurnMechanism.endTurnMechanism(session);
		session.setAttribute("mode", "move");

		return gameMat;
	
	}
	
	
}










/*
 * 
 * 
 * Monster Basic Line:
Melee: Pawn -> Brawler -> Chief
Ranged: Claw -> Sorcerer -> Necromancer
Collector: Goblin -> Hobgoblin -> Goblin Chief
Healer: Herbalist -> Mender -> Shaman
got it?































Human Basic Line:
Melee: Fighter -> Soldier -> Warrior
Ranged: Slinger -> Bowman -> Archer
Collector: Gatherer -> Collector -> Hoarder
Healer: Medic -> Doctor -> Specialist

 * */






