package com.zycus.model.human;

import com.zycus.model.Creature;

public class Human extends Creature {
	private String gene = "human";
	private int medicine;

	public Human(int life, int medicine) {
		super(life);
		this.medicine = medicine;
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public int getMedicine() {
		return medicine;
	}

	public void setMedicine(int medicine) {
		this.medicine = medicine;
	}

	public Human() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Human(int life) {
		super(life);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Human [gene=" + gene + ", medicine=" + medicine + "]";
	}

}
