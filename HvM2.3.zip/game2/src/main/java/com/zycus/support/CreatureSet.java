package com.zycus.support;

import java.util.HashSet;
import java.util.Set;

import com.zycus.model.Block;

public class CreatureSet {

	private static Set<Block> setOfHumans  = new HashSet<Block>();
	private static Set<Block> setOfMonsters = new HashSet<Block>();

	public boolean isHuman(String gene)
	{
		if(gene.equalsIgnoreCase("human"))
			return true;
		return false;
	}
	
	public void updateSet(String gene, Block oldBlock, Block newBlock)
	{
		if(isHuman(gene))
		{
			setOfHumans.add(newBlock);
			setOfHumans.remove(oldBlock);
		}
		else
		{
			setOfMonsters.add(newBlock);
			setOfMonsters.remove(oldBlock);
		}
	}
	
	public void remove(String gene, Block block)
	{
		if(isHuman(gene))
			setOfHumans.remove(block);
		else
			setOfMonsters.remove(block);
	}
	
	public void add(String gene, Block block)
	{
		if(!isHuman(gene))
			setOfHumans.add(block);
		else
			setOfMonsters.add(block);
	}
}
