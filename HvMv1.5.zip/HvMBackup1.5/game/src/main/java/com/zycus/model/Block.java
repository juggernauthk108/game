package com.zycus.model;

public class Block {
	Creature creature;
	int x;
	int y;

	public Block(Creature creature, int x, int y) {
		super();
		this.creature = creature;
		this.x = x;
		this.y = y;
	}

	public Block() {
		super();
	}

	public Creature getCreature() {
		return creature;
	}

	public void setCreature(Creature creature) {
		this.creature = creature;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Block [creature=" + creature + ", x=" + x + ", y=" + y + "]";
	}

}
