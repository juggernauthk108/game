package com.zycus.support;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import com.zycus.model.Creature;
import com.zycus.model.human.Fighter;
import com.zycus.model.human.Healer;
import com.zycus.model.human.Human;
import com.zycus.model.human.fighter.Soldier;
import com.zycus.model.monster.Claw;
import com.zycus.model.monster.Goblin;
import com.zycus.model.monster.Monster;
import com.zycus.model.monster.claw.Sorcerer;
import com.zycus.model.monster.claw.sorcerer.Necromancer;
import com.zycus.model.monster.goblin.Hoarder;

public class PossibleUpgrades 
{
	
	private static HashMap<String, ArrayList<Creature>> creatureTree = new HashMap<String, ArrayList<Creature>>();
	private static HashMap<String, Creature> creatureHash = new HashMap<String, Creature>();
	
	public static void loadCreatureTree()
	{
		creatureTree.put(new Human().getGene(), getUpgradesList((Fighter)new Fighter(), (Healer)new Healer()));
		creatureTree.put(new Fighter().getGene(), getUpgradesList((Soldier)new Soldier()));
		
		creatureTree.put(new Monster().getGene(), getUpgradesList((Goblin)new Goblin(), (Claw)new Claw()));
		creatureTree.put(new Goblin().getGene(), getUpgradesList((Hoarder)new Hoarder()));
		creatureTree.put(new Claw().getGene(), getUpgradesList((Sorcerer)new Sorcerer()));
		creatureTree.put(new Sorcerer().getGene(), getUpgradesList((Necromancer)new Necromancer()));
		
		loadCreatureHash();
	}
	
	public static HashMap<String, Creature> getCreatureHash() {
		return creatureHash;
	}

	public static void setCreatureHash(HashMap<String, Creature> creatureHash) {
		PossibleUpgrades.creatureHash = creatureHash;
	}

	public static void setCreatureTree(
			HashMap<String, ArrayList<Creature>> creatureTree) {
		PossibleUpgrades.creatureTree = creatureTree;
	}

	public static void loadCreatureHash()
	{
		creatureHash.put(new Human().getGene(), new Human());
		creatureHash.put(new Fighter().getGene(), new Fighter());
		creatureHash.put(new Soldier().getGene(), new Soldier());
		creatureHash.put(new Healer().getGene(), new Healer());
		
		creatureHash.put(new Monster().getGene(), new Monster());
		creatureHash.put(new Goblin().getGene(), new Goblin());
		creatureHash.put(new Hoarder().getGene(), new Hoarder());
		creatureHash.put(new Claw().getGene(), new Claw());
		creatureHash.put(new Sorcerer().getGene(), new Sorcerer());
		creatureHash.put(new Necromancer().getGene(), new Necromancer());
	}
	
	public static HashMap<String, ArrayList<Creature>> getCreatureTree() {
		return creatureTree;
	}

	public static ArrayList<Creature> getUpgradesList(Creature... creatures )
	{
		System.out.println("***inside upgradeController: "+Arrays.toString(creatures));
		return new ArrayList<Creature> (Arrays.asList(creatures));
	}
	
}