/*
 * game controller for v1.8
 * 
 * added:
 * endTurn mechanism
 * changed the end turn mechanism to (Human play -> Monster play -> both get gold) repeat
 * 
 * --added console ArrayList<String>
 * */


package com.zycus.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GameController {

	//dunno what to write here

}
