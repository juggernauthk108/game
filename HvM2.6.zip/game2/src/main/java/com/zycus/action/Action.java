package com.zycus.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.model.creature.Reaper;
import com.zycus.support.CreatureSet;
import com.zycus.support.DieRoll;

public class Action {

	public ArrayList<ArrayList<Block>> moveCreature(ArrayList<ArrayList<Block>> gameMat, int prevRow, int prevCol, int row, int col)
	{
		Block tempBlock = ((List<ArrayList<Block>>) gameMat).get(prevRow).get(prevCol);

		((List<ArrayList<Block>>) gameMat).get(row).get(col).setCreature(tempBlock.getCreature());

		tempBlock.setCreature(null);

		((List<ArrayList<Block>>) gameMat).get(prevRow).set(prevCol, tempBlock);
		
		return gameMat;
	}
	
	public ArrayList<ArrayList<Block>> attackCreature(HttpSession session, ArrayList<ArrayList<Block>> gameMat, Creature sourceCreature, Creature opponent, int oppx, int oppy)
	{
		//oopx : oppenent x co-ordinate
		//oppy : opponent y cooradinate
		
		//action.attackCreature(session, gameMat, prevRow, prevCol, prevRow, prevCol);
		CreatureSet creatureSet = new CreatureSet();
		
		int attackpoints = sourceCreature.getAttackPoints();
		int accuracy = sourceCreature.getAccuracy();

		if(opponent.getGene() == "roshan")
		{
			Reaper roshan = (Reaper) gameMat
											.get((Integer) session.getAttribute("reaperRow"))
											.get((Integer) session.getAttribute("reaperCol"))
											.getCreature();
			roshan.setState("angry");
			roshan.setAngryFor(10);
		}
		
		int oppLife = opponent.getLife();
		int oppArmor = opponent.getArmor();

		if (DieRoll.dieRoll() < accuracy || sourceCreature instanceof Reaper) { //Roshan does not giva a fox about his accuracy; when angry, Roshan does pure damage, not matter what!
			
			if(!(sourceCreature instanceof Reaper))
				attackpoints -= (oppArmor * attackpoints) / 100; //armor defence of the victim disabled if roshan is attacking; Roshan is pure damage

			// minimum attack points
			if (attackpoints <= 0)
				attackpoints = 80;
			
			else {
				if(!(sourceCreature instanceof Reaper))
					attackpoints = new AttackLuck().attackLuck(attackpoints);// no luck factor for roshan; Roshan is pure damage
			}

			// attack : reduce the life
			oppLife -= attackpoints;

			if (oppLife > 0) {
				opponent.setLife(oppLife);

				if(!(sourceCreature instanceof Reaper))
				{
					if(opponent.getArmor()>= 1)
						opponent.setArmor(oppArmor - 1); //Roshan does not take the armor; Roshan is good
				}
			}

			else {
				
				gameMat.get(oppx).get(oppy).setCreature(null);;
			//	creatureSet.remove((String)session.getAttribute("plays"), gameMat.get(row).get(col));

			}

		}

		else {
			System.out.println(sourceCreature.getGene()
					+ " missed");
		}
		
		return gameMat;
	}
	
	
}


/*
 * 
 * 
 * Monster Basic Line:
Melee: Pawn -> Brawler -> Chief
Ranged: Claw -> Sorcerer -> Necromancer
Collector: Goblin -> Hobgoblin -> Goblin Chief
Healer: Herbalist -> Mender -> Shaman
got it?

Human Basic Line:
Melee: Fighter -> Soldier -> Warrior
Ranged: Slinger -> Bowman -> Archer
Collector: Gatherer -> Collector -> Hoarder
Healer: Medic -> Doctor -> Specialist

 * */






