package com.zycus.model.creature;

import com.zycus.model.Creature;

public class Reaper extends Creature {
	private String gene = "roshan";
	private String parentGene = "roshan";
	private int slashRange = 3;
	

	public int getSlashRange() {
		return slashRange;
	}

	public void setSlashRange(int slashRange) {
		this.slashRange = slashRange;
	}

	private String state = "calm";

	private int angryFor = 10;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getGene() {
		return gene;
	}

	public int getAngryFor() {
		return angryFor;
	}

	public void setAngryFor(int angryFor) {
		this.angryFor = angryFor;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public String getParentGene() {
		return parentGene;
	}

	public void setParentGene(String parentGene) {
		this.parentGene = parentGene;
	}

	public Reaper() {
		super();
		super.setLife(5000);
		super.setMovementRange(2);
		super.setAttackPoints(300);
		super.setAttackRange(1);

		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Reaper [gene=" + gene + ", parentGene=" + parentGene
				+ ", state=" + state + ", angryFor=" + angryFor + "]";
	}

	
}