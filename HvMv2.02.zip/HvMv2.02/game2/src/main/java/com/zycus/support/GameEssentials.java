package com.zycus.support;

import java.util.ArrayList;
import java.util.Random;

import javax.servlet.http.HttpSession;

import com.zycus.model.Block;
import com.zycus.model.creature.Human;
import com.zycus.model.creature.Monster;
import com.zycus.model.creature.Reaper;

public class GameEssentials {

	private static ArrayList<ArrayList<Block>> gameMat;

	final static int gridSize = 10;

	public GameEssentials() {
		super();
	}

	public static ArrayList<ArrayList<Block>> getGameMat() {
		return gameMat;
	}

	public static void setGameMat(ArrayList<ArrayList<Block>> gameMat) {
		GameEssentials.gameMat = gameMat;
	}

	public static ArrayList<ArrayList<Block>> initializeGameMat(
			HttpSession session) {
		gameMat = new ArrayList<ArrayList<Block>>();

		CreatureSet creatureSet = new CreatureSet();
		ArrayList<Block> listOfBlocks = new ArrayList<Block>();
		Block block = null;

		for (int i = 0; i < gridSize; i++) {
			listOfBlocks = new ArrayList<Block>();

			for (int j = 0; j < gridSize; j++) {

				if (i == 0) {
					block = new Block(new Human(), i, j);
					creatureSet.add(block.getCreature().getGene(), block);
				}

				else {
					if (i == gridSize - 1) {
						block = new Block(new Monster(), i, j);
						creatureSet.add(block.getCreature().getGene(), block);
					}

					else {
						// inner else starts here
						block = new Block(null, i, j);

						block.setMoney(((new Random().nextInt() % 2) > 0) ? "yes"
								: null);

						if (block.getMoney() != null) {
							if (DieRoll.dieRoll() > 97) {
								block.setAmountMoney(DieRoll.dieRoll() + 100);
								System.out.println("Got Lucky at:" + "i: " + i
										+ " j: " + j);
							} else {
								block.setAmountMoney(DieRoll.dieRoll() / 2);
							}
						}

						// innner else ends here
					}
				}
				listOfBlocks.add(block);
			}

			gameMat.add(listOfBlocks);
			
			

		}
		
		int reaperRowDelta = (DieRoll.dieRoll()%2 == 0) ? 1 : -1;
		int reaperColDelta = (DieRoll.dieRoll()%2 == 0) ? 1 : -1;
		
		int reaperRow = gridSize/2 - 1 + reaperRowDelta;
		int reaperCol = gridSize/2 - 1 + reaperColDelta;
		
		System.out.println("EROROROROROORORO: "+reaperCol+", "+reaperRow);
		
		session.setAttribute("reaperRow", reaperRow);
		session.setAttribute("reaperCol", reaperCol);
		
		gameMat.get(reaperRow).get(reaperCol).setCreature(new Reaper());

		System.out.println("here size is: " + gameMat.size());
		System.out.println(gameMat);
		
		System.out.println("Reaper block : " + gameMat.get(reaperRow).get(reaperCol));

		return gameMat;
	}

}
