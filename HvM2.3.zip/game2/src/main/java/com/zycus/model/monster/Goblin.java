package com.zycus.model.monster;

public class Goblin extends Monster {
	private String gene = "goblin";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Goblin() {
		super();
		super.setUpgradeCost(10);
		// / super.setGene("goblin");
		// TODO Auto-generated constructor stub
	}

	public Goblin(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Goblin(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Goblin [gene=" + gene + "]";
	}

}
