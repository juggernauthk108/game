package com.zycus.support;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import com.zycus.model.Block;
import com.zycus.model.creature.Reaper;

public class EndTurnMechanism {
	
	public static void endTurnMechanism(HttpSession session) {
		int initFlagState = (Integer) session.getAttribute("initFlagState");

		if (ChanceMechanism.getFlag() == initFlagState) {
			session.setAttribute("noOfTurns",
					(Integer) session.getAttribute("noOfTurns") + 1);
			grantPassiveMoney(session);
		}
		
		int rosRow = (Integer) session.getAttribute("reaperRow");
		int rosCol = (Integer) session.getAttribute("reaperCol");
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		Reaper reaper = (Reaper) gameMat.get(rosRow).get(rosCol).getCreature();
		
		if(reaper.getState().equals("angry"))
		{
			if(reaper.getAngryFor() - 1 == 0)
			{
				reaper.setState("calm");
			}
			else{
				
				reaper.setAngryFor(reaper.getAngryFor() - 1);
				
				
				
			}
			
			
			
		}
		
	}

	public static void grantPassiveMoney(HttpSession session) {

		session.setAttribute("monsterMoney",
				(Integer) session.getAttribute("monsterMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

		session.setAttribute("humanMoney",
				(Integer) session.getAttribute("humanMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

	}
}
