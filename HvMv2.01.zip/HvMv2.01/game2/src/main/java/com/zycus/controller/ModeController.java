package com.zycus.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ModeController {
	@RequestMapping(value = "setModeMove", method = RequestMethod.GET)
	public String setModeMove(HttpSession session) {
		session.setAttribute("mode", "move");
		return "/startGame";
	}

	@RequestMapping(value = "setModeAttack", method = RequestMethod.GET)
	public String setModeAttack(HttpSession session) {
		session.setAttribute("mode", "attack");
		return "/startGame";
	}

	@RequestMapping(value = "setModeCollect", method = RequestMethod.GET)
	public String setModeCollect(HttpSession session) {
		session.setAttribute("mode", "collect");
		return "/startGame";
	}
}
