package com.zycus.passwordmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="Records")
public class Record {
	@Id
	private String userEmail;
	@Column
	private String siteUrl;
	@Column
	private String siteUserName;
	@Column
	private String siteUserPassword;

	public Record() {
		super();
	}

	public Record(String userEmail, String siteUrl, String siteUserName, String siteUserPassword) {
		super();
		this.userEmail = userEmail;
		this.siteUrl = siteUrl;
		this.siteUserName = siteUserName;
		this.siteUserPassword = siteUserPassword;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getSiteUrl() {
		return siteUrl;
	}

	public void setSiteUrl(String siteUrl) {
		this.siteUrl = siteUrl;
	}

	public String getSiteUserName() {
		return siteUserName;
	}

	public void setSiteUserName(String siteUserName) {
		this.siteUserName = siteUserName;
	}

	public String getSiteUserPassword() {
		return siteUserPassword;
	}

	public void setSiteUserPassword(String siteUserPassword) {
		this.siteUserPassword = siteUserPassword;
	}

	@Override
	public String toString() {
		return "Record [userEmail=" + userEmail + ", siteUrl=" + siteUrl + ", siteUserName=" + siteUserName
				+ ", siteUserPassword=" + siteUserPassword + "]";
	}
}