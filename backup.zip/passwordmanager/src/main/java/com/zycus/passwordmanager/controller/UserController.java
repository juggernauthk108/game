package com.zycus.passwordmanager.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.passwordmanager.model.Record;
import com.zycus.passwordmanager.model.User;
import com.zycus.passwordmanager.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService userService;
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = {"/","/index"}, method = RequestMethod.GET)
	public String getIndexPage(Model model) {
		model.addAttribute("userObj", new User());
		return "index";
	}
	
	@RequestMapping(value = {"/signup"}, method = RequestMethod.GET)
	public String getRegisterPage(Model model) {
		model.addAttribute("userObj", new User());
		return "signup";
	}
	
	@RequestMapping(value = {"/addkey"}, method = RequestMethod.GET)
	public String getAddKey(Model model) {
		model.addAttribute("recordObj", new Record());
		return "addkey";
	}
	
	@RequestMapping(value = {"/register"}, method = RequestMethod.POST)
	public String processRegister(@ModelAttribute("userObj") User user, Model model) {
		if(userService.register(user))
		{
			model.addAttribute("message", "Account created.");
			return "index";
		}
		else
		{
			model.addAttribute("message", "User already exists.");
			return "signup";
		}
	}
	
	@RequestMapping(value = {"/login"}, method = RequestMethod.POST)
	public String processLogin(@ModelAttribute("userObj") User user, HttpSession session, Model model) {
		System.out.println("User" + user);
		User check = userService.authenticate(user);
		System.out.println("Check: " + check);
		if(check!=null)
		{
			session.setAttribute("name", check.getUserName());
			model.addAttribute("message", "Login successfull");
			return "redirect:/index";
		}
		model.addAttribute("message", "Login failed.");
		return "redirect:/index";
	}
	
	@RequestMapping(value="/logout")
	public String processLogout(HttpSession session)
	{
		session.invalidate();
		return "redirect:/index";
	}
}
