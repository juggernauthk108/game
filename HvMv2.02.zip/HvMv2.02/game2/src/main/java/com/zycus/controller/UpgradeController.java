package com.zycus.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.model.monster.Goblin;
import com.zycus.support.ChanceMechanism;
import com.zycus.support.Console;
import com.zycus.support.EndTurnMechanism;
import com.zycus.support.PossibleUpgrades;

@Controller
public class UpgradeController {
	
	@RequestMapping(value = "/ingame/upgrade/{upgradeTo}/{row}/{col}", method = RequestMethod.GET)
	public String upgradeTo(@PathVariable String upgradeTo, @PathVariable int row, @PathVariable int col, HttpSession session) throws InstantiationException, IllegalAccessException, ClassNotFoundException, CloneNotSupportedException
	{
		/*
		 * upgradeToCreatureFromHash.getClass().getName().toString()
		 * */
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		
		System.out.println(upgradeTo);
		Creature upgradeToCreatureFromHash = PossibleUpgrades.getCreatureHash().get(upgradeTo);
		System.out.println("UUUUPGRADE TO: "+ upgradeToCreatureFromHash);
		
		//Creature upgradeToCreature = (Creature) Class.forName(upgradeToCreatureFromHash.getClass().getName().toString()).newInstance();
		
		Creature upgradeToCreature = (Creature) upgradeToCreatureFromHash.clone();
		
		System.out.println("@#$%^&@#@#: HERERE: "+upgradeToCreature);
		//System.out.println("@#$%!@#$%^@#$%^&*@#$%^&*():"+upgradeToCreatureFromHash.getClass().getName().toString());
		System.out.println("!@#$%^&*(@#$%^&@#e$r%t^y:"+ Goblin.class.toString().split(" ")[1]);
		
		System.out.println("this is the upgrade to creature: "+upgradeToCreature);
		
		System.out.println("!@#$%^&*@#$%^&LIFE: "+upgradeToCreature.getLife());

		String plays = (String) session.getAttribute("plays");
		Console.upgraded(plays, gameMat.get(row).get(col).getCreature(), upgradeToCreature, row, col, session);
		
		gameMat.get(row).get(col).setCreature(upgradeToCreature);
		
		session.setAttribute(plays+"Money", (Integer)session.getAttribute(plays+"Money") - upgradeToCreature.getUpgradeCost());
		
		session.setAttribute("board", gameMat);
		
		session.setAttribute("row", row);
		session.setAttribute("col", col);
		
		session.setAttribute("mode", "move");
		
		session.setAttribute("opp", session.getAttribute("plays"));
		session.setAttribute("plays", ChanceMechanism.chance());
		
		EndTurnMechanism.endTurnMechanism(session);
		
		return "/startGame";
	}
	
}
