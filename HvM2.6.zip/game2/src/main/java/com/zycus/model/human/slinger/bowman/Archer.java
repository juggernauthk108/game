package com.zycus.model.human.slinger.bowman;

import com.zycus.model.human.slinger.Bowman;

public class Archer extends Bowman {
	private String gene = "archer";

	public Archer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Archer(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Archer(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	@Override
	public String toString() {
		return "Archer [gene=" + gene + "]";
	}

}
