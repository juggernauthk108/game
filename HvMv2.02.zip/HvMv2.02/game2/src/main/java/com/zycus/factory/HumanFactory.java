package com.zycus.factory;

import com.zycus.model.creature.Human;
import com.zycus.model.human.Fighter;
import com.zycus.model.human.fighter.Soldier;

public class HumanFactory {

	public Human createInstance(String gene)
	{
		if(gene.equals("soldier"))
			return new Fighter();
		else
			if(gene.equals("soldier"))
				return new Soldier();
		
		return new Human();
	}
	
}
