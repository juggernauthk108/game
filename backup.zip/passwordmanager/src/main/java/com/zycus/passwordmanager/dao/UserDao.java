package com.zycus.passwordmanager.dao;

import com.zycus.passwordmanager.model.User;

public interface UserDao {
	public boolean register(User user);
	public User authenticate(User user);
}
