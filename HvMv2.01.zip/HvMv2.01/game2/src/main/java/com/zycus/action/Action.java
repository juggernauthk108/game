package com.zycus.action;

import java.util.ArrayList;
import java.util.List;

import com.zycus.model.Block;

public class Action {

	public ArrayList<ArrayList<Block>> moveCreature(ArrayList<ArrayList<Block>> gameMat, int prevRow, int prevCol, int row, int col)
	{
		Block tempBlock = ((List<ArrayList<Block>>) gameMat).get(prevRow).get(prevCol);

		((List<ArrayList<Block>>) gameMat).get(row).get(col).setCreature(tempBlock.getCreature());

		tempBlock.setCreature(null);

		((List<ArrayList<Block>>) gameMat).get(prevRow).set(prevCol, tempBlock);
		
		return gameMat;
	}
}
