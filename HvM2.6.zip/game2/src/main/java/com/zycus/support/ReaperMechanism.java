package com.zycus.support;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import com.zycus.action.Action;
import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.model.creature.Reaper;

public class ReaperMechanism {

	public void doReaperMechanism(HttpSession session)
	{
		checkReaperState(session);
	}
	
	public void checkReaperState(HttpSession session)
	{
		int rosRow = (Integer) session.getAttribute("reaperRow");
		int rosCol = (Integer) session.getAttribute("reaperCol");
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		Reaper reaper = (Reaper) gameMat.get(rosRow).get(rosCol).getCreature();
		
		if(reaper.getState().equals("angry"))
		{
			if(reaper.getAngryFor() - 1 == 0)
			{
				reaper.setState("calm");
			}
			else{
				if(DieRoll.dieRoll() < 10)
					stomp(session);
				else
					slash(session);
			}
			
			reaper.setAngryFor(reaper.getAngryFor() - 1);
		}
	}
	
	public void stomp(HttpSession session)
	{
		int x = (Integer) session.getAttribute("reaperRow") ;//roshan x coo-ordinate
		int y = (Integer) session.getAttribute("reaperCol") ;//roshan y co-ordinate
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		
		Reaper reaper = (Reaper)gameMat.get(x).get(y).getCreature();
		int range = reaper.getAttackRange(); // roshan hit range
		
		int xDelta = -range;
		int yDelta = -range;
		
		int xCheck = 0;
		int yCheck = 0;
		
		Action action = new Action();
		
		
		for(int i = 0 ; i< range * 2 +1 ; i++)//this loop does the range damage; when roshan is angry; Roshan does pure damage
		{
			yDelta = -range;
			for( int j = 0 ; j < range * 2 + 1 ; j++)
			{
				xCheck = x + xDelta;
				yCheck = y + yDelta;
				
				if(xCheck!=x || yCheck!=y)
				{
					//this block is entered if within damage area of the reaper
					if(xCheck > -1 && yCheck > -1 && xCheck < gameMat.size() && yCheck < gameMat.get(1).size())	{
						//making the roshan hit only inside the board
						Creature opponent = gameMat.get(xCheck).get(yCheck).getCreature();
						if(opponent!=null)
						{
							//stomp here
							System.out.println("Stomping by: "+opponent);
							action.attackCreature(session, gameMat, reaper, opponent, xCheck, yCheck);
						}
					}
				}
				yDelta++;
			}
			System.out.println();
			xDelta++;
		}
	}
	
	public void slash(HttpSession session)
	{
	
	int x = (Integer) session.getAttribute("reaperRow") ;//roshan x coo-ordinate
	int y = (Integer) session.getAttribute("reaperCol") ;//roshan y co-ordinate
	
	ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
	
	Reaper reaper = (Reaper)gameMat.get(x).get(y).getCreature();
	int range = reaper.getSlashRange(); // roshan hit range
	
	int xDelta = -range;
	int yDelta = -range;
	
	int xCheck = 0;
	int yCheck = 0;
	
	Action action = new Action();
	
	
	for(int i = 0 ; i< range * 2 +1 ; i++)//this loop does the range damage; when roshan is angry; Roshan does pure damage
	{
		yDelta = -range;
		for( int j = 0 ; j < range * 2 + 1 ; j++)
		{
			xCheck = x + xDelta;
			yCheck = y + yDelta;
			
			if(xCheck!=x || yCheck!=y)
			{
				//this block is entered if within damage area of the reaper
				if(xCheck > -1 && yCheck > -1 && xCheck < gameMat.size() && yCheck < gameMat.get(1).size())	
				{
					//making the roshan hit only inside the board
					Creature opponent = gameMat.get(xCheck).get(yCheck).getCreature();
					if(opponent!=null)
					{
						//slash logic here
						if(DieRoll.dieRoll() < 80)//80% chance that slash will happen
						{
							System.out.println("slashed: "+opponent+": -> "+xCheck+", "+yCheck);
							//attack that creature
							action.attackCreature(session, gameMat, reaper, opponent, xCheck, yCheck);
						}
						
					}
				
				}
			}
			yDelta++;
		}
		System.out.println();
		xDelta++;
	}
}
	
	public void pushBack(HttpSession session)
	{

		
		int x = (Integer) session.getAttribute("reaperRow") ;//roshan x coo-ordinate
		int y = (Integer) session.getAttribute("reaperCol") ;//roshan y co-ordinate
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		
		Reaper reaper = (Reaper)gameMat.get(x).get(y).getCreature();
		int range = reaper.getSlashRange(); // roshan hit range
		
		int xDelta = -range;
		int yDelta = -range;
		
		int xCheck = 0;
		int yCheck = 0;
		
		Action action = new Action();
		
		
		for(int i = 0 ; i< range * 2 +1 ; i++)//this loop does the range damage; when roshan is angry; Roshan does pure damage
		{
			yDelta = -range;
			for( int j = 0 ; j < range * 2 + 1 ; j++)
			{
				xCheck = x + xDelta;
				yCheck = y + yDelta;
				
				if(xCheck!=x || yCheck!=y)
				{
					//this block is entered if within damage area of the reaper
					if(xCheck > -1 && yCheck > -1 && xCheck < gameMat.size() && yCheck < gameMat.get(1).size())	
					{
						//making the roshan hit only inside the board
						Creature opponent = gameMat.get(xCheck).get(yCheck).getCreature();
						if(opponent!=null)
						{
							//write the pushBack code here, PLEASE!
						}
					
					}
				}
				yDelta++;
			}
			System.out.println();
			xDelta++;
		}

	}
}
























