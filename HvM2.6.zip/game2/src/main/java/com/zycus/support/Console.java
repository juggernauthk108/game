package com.zycus.support;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.zycus.model.Creature;

public class Console {

	private static List<String> console ;

	public Console() {
		super();
		Console.setConsole(new ArrayList<String>());
	}

	public static void setConsole(List<String> console) {
		Console.console = console;
	}

	public static List<String> getConsole() {
		return console;
	}

	public static void gameStart() {
		Console.console.clear();
		Console.console.add("game has been started");
	}

	public static void moved(String plays, int prevRow, int prevCol, int row, int col,
			HttpSession session) {
		
		String prepend = "TURN: " + (Integer) session.getAttribute("noOfTurns")
				+ " ";
		Console.console.add(prepend + plays + " moved from [" + prevRow + ", "
				+ prevCol + "] to [" + row + ", " + col + "]");
	}

	public static void attacked(String plays, int prevRow, int prevCol, int row,
			int col, HttpSession session) {
		String prepend = "TURN: " + (Integer) session.getAttribute("noOfTurns")
				+ " ";
		Console.console.add(prepend + plays + " attacked from [" + prevRow
				+ ", " + prevCol + "] to [" + row + ", " + col + "]");
	}

	public static void collected(String plays, int row, int col, HttpSession session) {
		String prepend = "TURN: " + (Integer) session.getAttribute("noOfTurns")
				+ " ";
		Console.console.add(prepend + plays + " collected money from [" + row
				+ ", " + col + "]");
	}

	public static void endTurn(String plays, HttpSession session)
	{
		String prepend = "TURN: " + (Integer) session.getAttribute("noOfTurns")
				+ " ";
		Console.console.add(prepend+plays+" ended turn");
	}
	
	public static void upgraded(String plays, Creature from, Creature to, int row, int col, HttpSession session)
	{
		String prepend = "TURN: " + (Integer) session.getAttribute("noOfTurns")+ " at ["+row+", "+col+"] ";
		Console.console.add(prepend+"upgraded "+from.getGene() +" to "+to.getGene()+" at cost: "+to.getUpgradeCost());
	}
}
