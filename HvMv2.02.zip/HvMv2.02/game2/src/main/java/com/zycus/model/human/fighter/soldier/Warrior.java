package com.zycus.model.human.fighter.soldier;

import com.zycus.model.human.fighter.Soldier;

public class Warrior extends Soldier{

	private String gene = "warrior";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	@Override
	public String toString() {
		return "Warrior [gene=" + gene + "]";
	}

	public Warrior() {
		super();
		// TODO Auto-generated constructor stub
	}

}
