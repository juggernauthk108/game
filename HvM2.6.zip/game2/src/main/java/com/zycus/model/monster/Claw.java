package com.zycus.model.monster;

import com.zycus.model.creature.Monster;

/**
 * @author tejas.zarekar
 * 
 */
public class Claw extends Monster {
	private String gene = "claw";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Claw() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Claw(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Claw(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Claw [gene=" + gene + "]";
	}

}
