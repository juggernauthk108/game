package com.zycus.support;

import javax.servlet.http.HttpSession;

public class EndTurnMechanism {
	
	public static void endTurnMechanism(HttpSession session) {
		int initFlagState = (Integer) session.getAttribute("initFlagState");

		if (ChanceMechanism.getFlag() == initFlagState) {
			session.setAttribute("noOfTurns",
					(Integer) session.getAttribute("noOfTurns") + 1);
			grantPassiveMoney(session);
		}
	}

	public static void grantPassiveMoney(HttpSession session) {

		session.setAttribute("monsterMoney",
				(Integer) session.getAttribute("monsterMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

		session.setAttribute("humanMoney",
				(Integer) session.getAttribute("humanMoney")
						+ (Integer) session.getAttribute("noOfTurns"));

	}
}
