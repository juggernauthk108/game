package com.zycus.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.support.ChanceMechanism;
import com.zycus.support.EndTurnMechanism;

@Controller
public class EndTurnController {
	@RequestMapping(value = "/endTurn", method = RequestMethod.GET)
	String endTurn(HttpSession session) {

		session.setAttribute("opp", session.getAttribute("plays"));

		session.setAttribute("plays", ChanceMechanism.chance());

		EndTurnMechanism.endTurnMechanism(session);

		return "/startGame";
	}
}
