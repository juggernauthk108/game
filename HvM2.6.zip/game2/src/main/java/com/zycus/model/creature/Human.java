package com.zycus.model.creature;

import com.zycus.model.Creature;

public class Human extends Creature {
	
	private int upgradeCost = 10;
	
	private int level = 1;
	
	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getUpgradeCost() {
		return upgradeCost;
	}

	public void setUpgradeCost(int upgradeCost) {
		this.upgradeCost = upgradeCost;
	}

	private String parentGene = "human";
	public String getParentGene() {
		return parentGene;
	}

	public void setParentGene(String parentGene) {
		this.parentGene = parentGene;
	}

	private String gene = "human";
	private int medicine;

	public Human(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange);
		this.gene = gene;
		this.medicine = medicine;
	}

	public Human() {
		super();
	}

	public Human(int life, int movementRange) {
		super(life, movementRange);
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public int getMedicine() {
		return medicine;
	}

	public void setMedicine(int medicine) {
		this.medicine = medicine;
	}

	@Override
	public String toString() {
		return "Human [gene=" + gene + ", medicine=" + medicine + "]";
	}

}
