package com.zycus.model.monster;

import com.zycus.model.creature.Monster;

public class Herbalist extends Monster {
	private String gene = "herbalist";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Herbalist() {
		super();
		super.setAttackPoints(250);
		// TODO Auto-generated constructor stub
	}

	public Herbalist(int life, int movementRange, String gene,
			int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Herbalist(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Herbalist [gene=" + gene + "]";
	}

}
