package com.zycus.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.Block;
import com.zycus.model.Creature;
import com.zycus.support.ChanceMechanism;
import com.zycus.support.EndTurnMechanism;
import com.zycus.support.PossibleUpgrades;

@Controller
public class UpgradeController {
	
	@RequestMapping(value = "/ingame/upgrade/{upgradeTo}/{row}/{col}", method = RequestMethod.GET)
	public String upgradeTo(@PathVariable String upgradeTo, @PathVariable int row, @PathVariable int col, HttpSession session)
	{
		
		ArrayList<ArrayList<Block>> gameMat = (ArrayList<ArrayList<Block>>) session.getAttribute("board");
		
		Creature upgradeToCreature = PossibleUpgrades.getCreatureHash().get(upgradeTo);
		
		System.out.println("this is the upgrade to creature: "+upgradeToCreature);
		
		gameMat.get(row).get(col).setCreature(upgradeToCreature);
		
		session.setAttribute("board", gameMat);
		
		session.setAttribute("row", row);
		session.setAttribute("col", col);
		
		session.setAttribute("mode", "move");
		
		session.setAttribute("opp", session.getAttribute("plays"));
		session.setAttribute("plays", ChanceMechanism.chance());
		
		EndTurnMechanism.endTurnMechanism(session);
		
		return "/startGame";
	}
	
}
