package com.zycus.model.human;

public class Fighter extends Human {
	
	private int level = 2;
	private String gene = "fighter";
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getGene() {
		return gene;
	}
	public void setGene(String gene) {
		this.gene = gene;
	}
	public Fighter() {
		super();
		//super.setGene("fighter");
		super.setUpgradeCost(10);
	}
	public Fighter(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
	}
	public Fighter(int life, int movementRange) {
		super(life, movementRange);
	}
	@Override
	public String toString() {
		return "Fighter [level=" + level + ", gene=" + gene + "]";
	}
	
}
