package com.zycus.model;

public class Creature {
	private int life;

	public Creature(int life) {
		super();
		this.life = life;
	}

	public Creature() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	@Override
	public String toString() {
		return "Creature [life=" + life + "]";
	}

}
