package com.zycus.model.human;

import com.zycus.model.creature.Human;

public class Gatherer extends Human {

	private String gene = "gatherer";
	
	public Gatherer() {
		super();
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	@Override
	public String toString() {
		return "Gatherer [gene=" + gene + "]";
	}

	public Gatherer(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Gatherer(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}
	
}
