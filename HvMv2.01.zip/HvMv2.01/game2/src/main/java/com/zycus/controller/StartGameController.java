package com.zycus.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.model.Block;
import com.zycus.support.ChanceMechanism;
import com.zycus.support.Console;
import com.zycus.support.GameEssentials;

@Controller
public class StartGameController {

	@RequestMapping(value = "/startGame", method = RequestMethod.GET)
	public String startGame(HttpSession session) {
		
		System.out.println("inside the startGmae Controlelr");
		
		ArrayList<ArrayList<Block>> gameMat = GameEssentials.initializeGameMat();

		session.setAttribute("mode", "move");
		session.setAttribute("row", 0);
		session.setAttribute("col", 0);

		String ch = ChanceMechanism.chance();

		session.setAttribute("opp", ChanceMechanism.getOpp(ch));
		session.setAttribute("plays", ch);
		session.setAttribute("pastCreature", null);
		session.setAttribute("board", gameMat);
		session.setAttribute("monsterMoney", 0);
		session.setAttribute("humanMoney", 0);
		session.setAttribute("noOfTurns", 0);
		
		Console.gameStart();
		session.setAttribute("console", Console.getConsole());
		
		// saving the state of the flag; for end turn mechanism
		session.setAttribute("initFlagState", ChanceMechanism.getFlag());

		return "/startGame";
	}
}
