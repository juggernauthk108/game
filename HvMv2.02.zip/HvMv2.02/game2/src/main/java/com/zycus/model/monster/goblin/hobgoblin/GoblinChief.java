package com.zycus.model.monster.goblin.hobgoblin;

import com.zycus.model.monster.goblin.HobGoblin;

public class GoblinChief extends HobGoblin {
	private String gene = "GoblinChief";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public GoblinChief() {
		super();
	}

	public GoblinChief(int life, int movementRange, String gene,
			int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public GoblinChief(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "GoblinChief [gene=" + gene + "]";
	}

}
