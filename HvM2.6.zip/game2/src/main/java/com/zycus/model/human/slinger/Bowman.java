package com.zycus.model.human.slinger;

import com.zycus.model.human.Slinger;

public class Bowman extends Slinger {
	private String gene = "bowman";

	public Bowman() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bowman(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Bowman(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	@Override
	public String toString() {
		return "Bowman [gene=" + gene + "]";
	}

}
