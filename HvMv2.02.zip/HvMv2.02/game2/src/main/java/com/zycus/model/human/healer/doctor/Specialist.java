package com.zycus.model.human.healer.doctor;

import com.zycus.model.human.healer.Doctor;

public class Specialist extends Doctor {
	private String gene = "specialist";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Specialist() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Specialist(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}

	public Specialist(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Specialist [gene=" + gene + "]";
	}

}
