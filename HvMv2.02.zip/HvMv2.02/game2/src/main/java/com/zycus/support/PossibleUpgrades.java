package com.zycus.support;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import com.zycus.model.Creature;
import com.zycus.model.creature.Human;
import com.zycus.model.creature.Monster;
import com.zycus.model.human.Fighter;
import com.zycus.model.human.Gatherer;
import com.zycus.model.human.Healer;
import com.zycus.model.human.Slinger;
import com.zycus.model.human.fighter.Soldier;
import com.zycus.model.human.fighter.soldier.Warrior;
import com.zycus.model.human.gatherer.Collector;
import com.zycus.model.human.gatherer.collector.Hoarder;
import com.zycus.model.human.healer.Doctor;
import com.zycus.model.human.healer.doctor.Specialist;
import com.zycus.model.human.slinger.Bowman;
import com.zycus.model.human.slinger.bowman.Archer;
import com.zycus.model.monster.Claw;
import com.zycus.model.monster.Goblin;
import com.zycus.model.monster.Herbalist;
import com.zycus.model.monster.Pawn;
import com.zycus.model.monster.claw.Sorcerer;
import com.zycus.model.monster.claw.sorcerer.Necromancer;
import com.zycus.model.monster.goblin.HobGoblin;
import com.zycus.model.monster.goblin.hobgoblin.GoblinChief;
import com.zycus.model.monster.herbalist.Mender;
import com.zycus.model.monster.herbalist.mender.Shaman;
import com.zycus.model.monster.pawn.Brawler;
import com.zycus.model.monster.pawn.brawler.Chief;

public class PossibleUpgrades 
{
	
	private static HashMap<String, ArrayList<Creature>> creatureTree = new HashMap<String, ArrayList<Creature>>();
	private static HashMap<String, Creature> creatureHash = new HashMap<String, Creature>();
	
	public static void loadCreatureTree()
	{
		//human tree
		creatureTree.put(new Human().getGene(), getUpgradesList(new Fighter(), new Slinger(), new Gatherer(), new Healer()));
		
		creatureTree.put(new Fighter().getGene(), getUpgradesList((Soldier)new Soldier()));
		creatureTree.put(new Soldier().getGene(), getUpgradesList(new Warrior()));
		
		creatureTree.put(new Slinger().getGene(), getUpgradesList(new Bowman()));
		creatureTree.put(new Bowman().getGene(), getUpgradesList(new Archer()));
		
		creatureTree.put(new Gatherer().getGene(), getUpgradesList(new Collector()));
		
		creatureTree.put(new Collector().getGene(), getUpgradesList(new Hoarder()));
		
		creatureTree.put(new Healer().getGene(), getUpgradesList(new Doctor()));
		creatureTree.put(new Doctor().getGene(), getUpgradesList(new Specialist()));
		
		
		//monster tree
		creatureTree.put(new Monster().getGene(), getUpgradesList((Claw)new Claw(), new Pawn(), new Goblin(), new Herbalist()));
		
		creatureTree.put(new Claw().getGene(), getUpgradesList((Sorcerer)new Sorcerer()));
		creatureTree.put(new Sorcerer().getGene(), getUpgradesList((Necromancer)new Necromancer()));
		
		creatureTree.put(new Pawn().getGene(), getUpgradesList(new Brawler()));
		creatureTree.put(new Brawler().getGene(), getUpgradesList(new Chief()));
		
		creatureTree.put(new Goblin().getGene(), getUpgradesList(new HobGoblin()));
		creatureTree.put(new HobGoblin().getGene(), getUpgradesList(new GoblinChief()));
		
		creatureTree.put(new Herbalist().getGene(), getUpgradesList(new Mender()));
		creatureTree.put(new Mender().getGene(), getUpgradesList(new Shaman()));
		
		
		loadCreatureHash();
	}
	
	public static HashMap<String, Creature> getCreatureHash() {
		return creatureHash;
	}

	public static void setCreatureHash(HashMap<String, Creature> creatureHash) {
		PossibleUpgrades.creatureHash = creatureHash;
	}

	public static void setCreatureTree(
			HashMap<String, ArrayList<Creature>> creatureTree) {
		PossibleUpgrades.creatureTree = creatureTree;
	}

	public static void loadCreatureHash()
	{
		creatureHash.put(new Human().getGene(), new Human());
		
		creatureHash.put(new Fighter().getGene(), new Fighter());
		creatureHash.put(new Soldier().getGene(), new Soldier());
		
		creatureHash.put(new Healer().getGene(), new Healer());
		
		creatureHash.put(new Doctor().getGene(), new Doctor());
		
		creatureHash.put(new Warrior().getGene(), new Warrior());
		
		creatureHash.put(new Slinger().getGene(), new Slinger());
		creatureHash.put(new Bowman().getGene(), new Bowman());
		creatureHash.put(new Archer().getGene(), new Archer());
		
		creatureHash.put(new Gatherer().getGene(), new Gatherer());
		creatureHash.put(new Collector().getGene(), new Collector());
		creatureHash.put(new Hoarder().getGene(), new Hoarder());
		
		creatureHash.put(new Monster().getGene(), new Monster());
	
		creatureHash.put(new Claw().getGene(), new Claw());
		creatureHash.put(new Sorcerer().getGene(), new Sorcerer());
		creatureHash.put(new Necromancer().getGene(), new Necromancer());
		
		creatureHash.put(new Pawn().getGene(), new Pawn());
		creatureHash.put(new Brawler().getGene(), new Brawler());
		creatureHash.put(new Chief().getGene(), new Chief());
		
		creatureHash.put(new Goblin().getGene(), new Goblin());
		creatureHash.put(new HobGoblin().getGene(), new HobGoblin());
		creatureHash.put(new GoblinChief().getGene(), new GoblinChief());
		
		creatureHash.put(new Herbalist().getGene(), new Herbalist());
		creatureHash.put(new Mender().getGene(), new Mender());
		creatureHash.put(new Shaman().getGene(), new Shaman());
	

		creatureHash.put(new Specialist().getGene(), new Specialist());
	}
	
	public static HashMap<String, ArrayList<Creature>> getCreatureTree() {
		return creatureTree;
	}

	public static ArrayList<Creature> getUpgradesList(Creature... creatures )
	{
		System.out.println("***inside upgradeController: "+Arrays.toString(creatures));
		return new ArrayList<Creature> (Arrays.asList(creatures));
	}
	
}