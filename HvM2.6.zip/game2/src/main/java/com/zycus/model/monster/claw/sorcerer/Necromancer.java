package com.zycus.model.monster.claw.sorcerer;

import com.zycus.model.monster.claw.Sorcerer;

public class Necromancer extends Sorcerer {
	private String gene = "necromancer";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Necromancer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Necromancer(int life, int movementRange, String gene,
			int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Necromancer(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Necromancer [gene=" + gene + "]";
	}

}
