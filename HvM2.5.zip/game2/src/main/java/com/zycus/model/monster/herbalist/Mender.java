package com.zycus.model.monster.herbalist;

import com.zycus.model.monster.Herbalist;

public class Mender extends Herbalist {
	private String gene = "mender";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public Mender() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mender(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public Mender(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Mender [gene=" + gene + "]";
	}

}
