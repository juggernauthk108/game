package com.zycus.support;

import java.util.ArrayList;
import java.util.HashMap;

import com.zycus.model.Creature;
import com.zycus.model.human.Fighter;
import com.zycus.model.human.Healer;
import com.zycus.model.human.Soldier;
import com.zycus.model.monster.Goblin;
import com.zycus.model.monster.Hoarder;

public class PossibleUpgrades {

	private static ArrayList<Creature> possibleHumanUpgradeList = new ArrayList<Creature>();
	private static ArrayList<Creature> possibleMonsterUpgradeList = new ArrayList<Creature>();
	
	private static HashMap<String, Creature> creatureHash = new HashMap();

	private static boolean isHumanDone = false;
	private static boolean isMonsterDone = false;

	
	//this is to be implemented with Class.forName() methods...
	public static void loadPossibleHumanUpgradeList()
	{
		if(!isHumanDone)
		{
			isHumanDone = true;
			
			possibleHumanUpgradeList.add(new Fighter());
			
			creatureHash.put(possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1).getGene(), possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1));
			
			possibleHumanUpgradeList.add(new Soldier());
			
			creatureHash.put(possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1).getGene(), possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1));
			
			possibleHumanUpgradeList.add(new Healer());
			
			creatureHash.put(possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1).getGene(), possibleHumanUpgradeList.get(possibleHumanUpgradeList.size()-1));
		}
	}
	
	public static void loadPossibleMonsterUpgradeList()
	{
		if(!isMonsterDone)
		{
			isMonsterDone = true;
			
			possibleMonsterUpgradeList.add(new Goblin());
			
			creatureHash.put(possibleMonsterUpgradeList.get(possibleMonsterUpgradeList.size()-1).getGene(), possibleMonsterUpgradeList.get(possibleMonsterUpgradeList.size()-1));
			
			possibleMonsterUpgradeList.add(new Hoarder());
			
			creatureHash.put(possibleMonsterUpgradeList.get(possibleMonsterUpgradeList.size()-1).getGene(), possibleMonsterUpgradeList.get(possibleMonsterUpgradeList.size()-1));
		}
	}

	public static HashMap<String, Creature> getCreatureHash() {
		return creatureHash;
	}

	public static void setCreatureHash(HashMap<String, Creature> creatureHash) {
		PossibleUpgrades.creatureHash = creatureHash;
	}

	public static ArrayList<Creature> getPossibleHumanUpgradeList() {
		return possibleHumanUpgradeList;
	}

	public static void setPossibleHumanUpgradeList(
			ArrayList<Creature> possibleHumanUpgradeList) {
		PossibleUpgrades.possibleHumanUpgradeList = possibleHumanUpgradeList;
	}

	public static ArrayList<Creature> getPossibleMonsterUpgradeList() {
		return possibleMonsterUpgradeList;
	}

	public static void setPossibleMonsterUpgradeList(
			ArrayList<Creature> possibleMonsterUpgradeList) {
		PossibleUpgrades.possibleMonsterUpgradeList = possibleMonsterUpgradeList;
	}

	public static boolean isHumanDone() {
		return isHumanDone;
	}

	public static void setHumanDone(boolean isHumanDone) {
		PossibleUpgrades.isHumanDone = isHumanDone;
	}

	public static boolean isMonsterDone() {
		return isMonsterDone;
	}

	public static void setMonsterDone(boolean isMonsterDone) {
		PossibleUpgrades.isMonsterDone = isMonsterDone;
	}
	
	
	
}
