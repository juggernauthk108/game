package com.zycus.model.monster;

import com.zycus.model.Creature;

public class Monster extends Creature {
	private String gene = "monster";
	private int infectionRating;

	public Monster(int life, int infectionRating) {
		super(life);
		this.infectionRating = infectionRating;
	}

	public Monster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Monster(int life) {
		super(life);
		// TODO Auto-generated constructor stub
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public int getInfectionRating() {
		return infectionRating;
	}

	public void setInfectionRating(int infectionRating) {
		this.infectionRating = infectionRating;
	}

	@Override
	public String toString() {
		return "Monster [gene=" + gene + ", infectionRating=" + infectionRating + "]";
	}

}
