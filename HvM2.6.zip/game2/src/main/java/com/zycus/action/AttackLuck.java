package com.zycus.action;

import java.util.Random;

import com.zycus.support.DieRoll;

public class AttackLuck {

	public int attackLuck(int attackpoints) {
		int delta = (new Random().nextInt(attackpoints / 4)) + 1;

		if (DieRoll.dieRoll() % 2 == 0)
			attackpoints += delta;
		else
			attackpoints -= delta;

		if (delta > attackpoints / 5)
			System.out.println("CRITICAL HIT");
		
		return attackpoints;
	}
	
}
