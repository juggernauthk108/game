package com.zycus.support;

import java.util.Random;

public class DieRoll {
	static public int dieRoll() {
		return new Random().nextInt(101) + 1;
	}
}
