package com.zycus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.support.Console;

@Controller
public class IndexController {
	
	Console consoleObj ;
	
	@RequestMapping(value = {"/index","/"}, method = RequestMethod.GET)
	public String getIndex() {
		this.consoleObj = new Console();
		return "/index";
	}

}
