package com.zycus.model.monster.goblin;

import com.zycus.model.monster.Goblin;

public class HobGoblin extends Goblin {
	private String gene = "hobgoblin";

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public HobGoblin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HobGoblin(int life, int movementRange, String gene,
			int infectionRating) {
		super(life, movementRange, gene, infectionRating);
		// TODO Auto-generated constructor stub
	}

	public HobGoblin(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "HobGoblin [gene=" + gene + "]";
	}

}
