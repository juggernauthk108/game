package com.zycus.model.creature;

import com.zycus.model.Creature;

public class Monster extends Creature {

	private int upgradeCost = 10;

	private int level = 1;

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getUpgradeCost() {
		return upgradeCost;
	}

	public void setUpgradeCost(int upgradeCost) {
		this.upgradeCost = upgradeCost;
	}

	private String parentGene = "monster";

	public String getParentGene() {
		return parentGene;
	}

	public void setParentGene(String parentGene) {
		this.parentGene = parentGene;
	}

	private String gene = "monster";
	private int infectionRating;

	public Monster(int life, int movementRange, String gene, int infectionRating) {
		super(life, movementRange);
		this.gene = gene;
		this.infectionRating = infectionRating;
	}

	public Monster() {
		super();
	}

	public Monster(int life, int movementRange) {
		super(life, movementRange);
	}

	public String getGene() {
		return gene;
	}

	public void setGene(String gene) {
		this.gene = gene;
	}

	public int getInfectionRating() {
		return infectionRating;
	}

	public void setInfectionRating(int infectionRating) {
		this.infectionRating = infectionRating;
	}

	@Override
	public String toString() {
		return "Monster [gene=" + gene + ", infectionRating=" + infectionRating
				+ "]";
	}
}