package com.zycus.model.human;

public class Soldier extends Human {
	private int level = 3;
	private String gene = "soldier";
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getGene() {
		return gene;
	}
	public void setGene(String gene) {
		this.gene = gene;
	}
	public Soldier() {
		super();
		super.setUpgradeCost(20);
		// TODO Auto-generated constructor stub
	}
	public Soldier(int life, int movementRange, String gene, int medicine) {
		super(life, movementRange, gene, medicine);
		// TODO Auto-generated constructor stub
	}
	public Soldier(int life, int movementRange) {
		super(life, movementRange);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
