package com.zycus.service;

import com.zycus.model.Board;

public class GameManger {

	
	public Board createBoard(int rows, int cols)
	{
		return null;
	}
	
	public Board action(int fromRow, int fromCol, int toRow, int toCol)
	{
		return null;
	}
	
}
