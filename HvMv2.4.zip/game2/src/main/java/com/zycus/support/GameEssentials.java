package com.zycus.support;

import java.util.ArrayList;
import java.util.Random;

import com.zycus.model.Block;
import com.zycus.model.creature.Human;
import com.zycus.model.creature.Monster;

public class GameEssentials {
	
	private static ArrayList<ArrayList<Block>> gameMat;
	
	final static int gridSize = 10;

	public GameEssentials() {
		super();
	}

	public static ArrayList<ArrayList<Block>> getGameMat() {
		return gameMat;
	}

	public static void setGameMat(ArrayList<ArrayList<Block>> gameMat) {
		GameEssentials.gameMat = gameMat;
	}

	public static ArrayList<ArrayList<Block>> initializeGameMat()
	{
		gameMat = new ArrayList<ArrayList<Block>>();
		
		CreatureSet creatureSet = new CreatureSet();
		ArrayList<Block> listOfBlocks = new ArrayList<Block>();
		Block block;
		
		for (int i = 0; i < gridSize; i++) {
			listOfBlocks = new ArrayList<Block>();

			for (int j = 0; j < gridSize; j++) {

				
				
				if(i==0)
				{
					block = new Block(new Human(), i, j);
					creatureSet.add(block.getCreature().getGene(), block);
				}
				
				else
				{
					if(i == gridSize - 1)
					{
						block = new Block(new Monster(), i, j);
						creatureSet.add(block.getCreature().getGene(), block);
					}
					
					else
					{
						block = new Block(null, i, j);

						block.setMoney(((new Random().nextInt() % 2) > 0) ? "yes"
								: null);

						if (block.getMoney() != null) {
							if (DieRoll.dieRoll() > 97) {
								block.setAmountMoney(DieRoll.dieRoll() + 100);
								System.out.println("Got Lucky at:" + "i: " + i
										+ " j: " + j);
							} else {
								block.setAmountMoney(DieRoll.dieRoll() / 2);
							}
						}
					}
				}
				listOfBlocks.add(block);
			}
			
			gameMat.add(listOfBlocks);
			
		}
		
		System.out.println("here size is: "+gameMat.size());
		System.out.println(gameMat);
		
		return gameMat;
	}
	

}
